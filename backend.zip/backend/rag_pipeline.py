from backend.vector_store import search_docs, search_code
from backend.llm_loader import load_llm

llm = load_llm()


def build_prompt(question, context, domain, mode):

    # ----- CODE MODES -----
    if domain == "code":
        if mode == "Explain":
            return f"""
Explain what this code does in simple language.

Code:
{context}
"""
        if mode == "Debug":
            return f"""
Find and explain bugs in the code and why they occur.

Code:
{context}
"""
        if mode == "Fix":
            return f"""
Fix the following code and explain the changes.

Code:
{context}
"""
        if mode == "Refactor":
            return f"""
Refactor the following code to be cleaner and more pythonic.
Do not change behavior unless necessary.

Code:
{context}
"""
        if mode == "Add Comments":
            return f"""
Add meaningful comments to each line of the code.

Code:
{context}
"""
        if mode == "Complexity":
            return f"""
Analyze the time and space complexity of the following code.

Code:
{context}
"""

    # ----- DOCUMENT MODES -----
    if domain == "doc":
        if mode == "Summarize":
            return f"""
Summarize the following text:

{context}
"""
        if mode == "Bullet Points":
            return f"""
Extract the key bullet points from the following text:

{context}
"""
        if mode == "Keywords":
            return f"""
Extract the important keywords:

{context}
"""
        # Default doc QA
        if mode == "Answer":
            return f"""
Answer the question using only the context.

Context:
{context}

Question:
{question}
"""

    # ----- FALLBACK -----
    return f"""
Answer using only this context:

{context}

Question:
{question}
"""


def rag_query(question, domain, mode):

    # retrieve context
    if domain == "code":
        docs = search_code(question)
    else:
        docs = search_docs(question)

    # join chunks
    if isinstance(docs, list):
        context = "\n\n".join(docs)
    else:
        context = docs

    prompt = build_prompt(question, context, domain, mode)
    answer = llm(prompt)
    return answer, context
