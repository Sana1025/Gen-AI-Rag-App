from fastapi import FastAPI, UploadFile, File
from pydantic import BaseModel
from pathlib import Path
import shutil

from backend.doc_loader import load_document
from backend.code_loader import load_code
from backend.utils import chunk_docs
from backend.vector_store import create_vectorstore, load_vectorstore
from backend.rag_pipeline import load_llm, build_prompt


app = FastAPI()

UPLOAD_DOC_DIR = Path("data/uploads")
UPLOAD_CODE_DIR = Path("data/code")
VECTOR_DOC_STORE = Path("data/vectorstore/docs")
VECTOR_CODE_STORE = Path("data/vectorstore/code")

# Ensure folders exist
for p in [UPLOAD_DOC_DIR, UPLOAD_CODE_DIR, VECTOR_DOC_STORE, VECTOR_CODE_STORE]:
    p.mkdir(parents=True, exist_ok=True)


@app.get("/")
def root():
    return {"message": "RAG Backend Running"}


# ----------- UPLOAD DOCUMENTS -----------
@app.post("/upload/doc")
async def upload_doc(file: UploadFile = File(...)):
    path = UPLOAD_DOC_DIR / file.filename

    with open(path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    docs = load_document(str(path))
    chunks = chunk_docs(docs)

    create_vectorstore(chunks, str(VECTOR_DOC_STORE))

    return {"filename": file.filename, "chunks": len(chunks), "status": "document indexed"}


# ----------- UPLOAD CODE -----------
@app.post("/upload/code")
async def upload_code(file: UploadFile = File(...)):
    path = UPLOAD_CODE_DIR / file.filename

    with open(path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    docs = load_code(str(path))
    chunks = chunk_docs(docs, chunk_size=400, overlap=20)

    create_vectorstore(chunks, str(VECTOR_CODE_STORE))

    return {"filename": file.filename, "chunks": len(chunks), "status": "code indexed"}


# ----------- QUERY ENDPOINT -----------
class Query(BaseModel):
    question: str
    domain: str  # "doc" or "code"
    mode: str    # NEW


@app.post("/query")
async def query_rag(q: Query):
    if q.domain == "doc":
        vs = load_vectorstore(str(VECTOR_DOC_STORE))
    elif q.domain == "code":
        vs = load_vectorstore(str(VECTOR_CODE_STORE))
    else:
        return {"error": "domain must be doc or code"}

    retriever = vs.as_retriever(search_kwargs={"k": 3})
    docs = retriever.get_relevant_documents(q.question)

    context = "\n\n".join([d.page_content for d in docs])

    llm = load_llm()
    prompt = build_prompt(q.question, context, q.domain, q.mode)
    answer = llm(prompt)

    return {
        "question": q.question,
        "mode": q.mode,
        "answer": answer,
        "context": context,
        "domain": q.domain
    }


# ----------- RESET STORES -----------
@app.post("/reset")
async def reset():
    shutil.rmtree(VECTOR_DOC_STORE, ignore_errors=True)
    shutil.rmtree(VECTOR_CODE_STORE, ignore_errors=True)
    VECTOR_DOC_STORE.mkdir(parents=True, exist_ok=True)
    VECTOR_CODE_STORE.mkdir(parents=True, exist_ok=True)
    return {"status": "vectorstores cleared"}
