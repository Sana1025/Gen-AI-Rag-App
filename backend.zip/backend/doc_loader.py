from langchain_community.document_loaders import PyPDFLoader, TextLoader
from pathlib import Path

def load_document(path: str):
    ext = Path(path).suffix.lower()

    if ext == ".pdf":
        loader = PyPDFLoader(path)
        return loader.load()
    elif ext in [".txt", ".md"]:
        loader = TextLoader(path)
        return loader.load()
    else:
        raise Exception(f"Unsupported document type: {ext}")
