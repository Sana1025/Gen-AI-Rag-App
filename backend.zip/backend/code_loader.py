from pathlib import Path
from langchain.docstore.document import Document

def load_code(path: str):
    ext = Path(path).suffix.lower()

    if ext not in [".py", ".js", ".ts"]:
        raise Exception(f"Unsupported code type: {ext}")

    with open(path, "r", encoding="utf-8") as f:
        code = f.read()

    # store as document chunk
    return [Document(page_content=code)]
